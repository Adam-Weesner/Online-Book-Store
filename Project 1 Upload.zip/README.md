Class: 		CPSC 332
Date: 		Fall 2018
Project: 	Online Book Store

Members:
			Adam Weesner - aweesner@csu.fullerton.edu
			Erik Lipsky - eriklipsky@csu.fullerton.edu

Development Stack: 
			LAMP (WAMP will not compile)

Directions:
			Extract Parana folder to var/www/html
			Run Parana.sql using LAMP
			Either change credentials to root/root or edit each file to your user/pass in each .php file

Pages:
			index.php 		|| login page
			memberLogin.php || sign up page
			home.php 		|| main page
			browse.php		|| category results page from side menu
			search.php		|| results from navbar search
			personal.php	|| edit personal information
			cart.php		|| cart page
			
			