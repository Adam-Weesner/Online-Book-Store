<html>
<body>

Welcome <?php echo $_GET["fName"]; ?>

</body>
</html>

