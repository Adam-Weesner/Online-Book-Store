<!DOCTYPE html>
<html lang="en">

<?php
  $db = new mysqli('localhost','root','root','Members');
  if ($db->connect_error) {
        die("Connection failed: " . $db->connect_error);
    }

	$user = $_POST['userID'];
	$query = "SELECT * FROM MemberList WHERE userID = '$user'";
	$result = mysqli_query($db, $query);
	$rows = $result->num_rows;

	if(isset($_POST['submit']) && $rows != 0) {
		try {
			echo "";
			
		}
		catch(Exception $e){
			echo "<script>alert('Wrong User ID or Password. Please try again.');</script>";
		}
	}
?>

<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="">
	<meta name="author" content="">
	<link rel="icon" href="files/icon.png">
	<link href="files/bootstrap.css" rel="stylesheet">
	<link href="files/index.css" rel="stylesheet">
	<title>Online Book Store</title>
</head>

<body class="text-center">
	<form class="form-signin" method='post'>
		<img class="logo" src="files/Parana.png">
		<h1 class="h3 mb-3 font-weight-normal"><font color="white">Please sign in</font></h1>

		<label for="inputUser" class="sr-only">User ID</label>
		<input type="text" name="subject" class="form-control" placeholder="Subject" required="true">

		<button class="btn btn-lg btn-primary btn-block" name='search' type="submit">Search</button>

	</form>
</body>
</html>
